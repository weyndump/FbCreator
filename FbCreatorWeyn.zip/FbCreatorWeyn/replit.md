# Facebook Account Creator Tool

## Overview
This is a Python-based CLI tool that automates the creation of Facebook accounts using temporary email addresses. The tool was imported from GitHub and completely rewritten with Filipino and RPW (role-play world) names support, along with advanced features.

**Current State**: Configured and ready to run. The application is a command-line interface tool that runs interactively with full customization options.

## Project Structure
- `weynFBCreate.py` - Main Python script that creates Facebook accounts using advanced registration method
- `requirements.txt` - Python dependencies (requests, faker, beautifulsoup4, fake_email, fake-useragent)
- `username.txt` - Output file for generated accounts (created at runtime)

## Dependencies
- Python 3.11
- requests - HTTP library for API calls
- faker - Library for generating fake user data
- beautifulsoup4 - HTML parsing library
- fake_email - Temporary email generation library
- fake-useragent - Random user agent generation
- Built-in modules: os, sys, re, time, json, random, string, hashlib

## Features
- **Name Options**: Choose between Filipino names or RPW (role-play world) names
- **Gender Selection**: Choose male or female for consistent name generation
- **Birthday Range**: Automatically generates birthdates between 1990-2003
- **Password Options**: Auto-generated (Name + 4 digits) or custom password
- **Simplified Output**: Shows only name, email, password, and user ID
- **No Email Confirmation**: Accounts are created without requiring OTP/email verification
- **Dynamic Token Extraction**: Uses fresh session tokens for each registration attempt
- **Clean Account Storage**: Saves accounts in organized format to username.txt

## How to Use
1. **Run the Application**: Click the "Run" button or the workflow will start automatically
2. **Select Name Type**: Choose between Filipino names (1) or RPW names (2)
3. **Select Gender**: Choose male (1) or female (2)
4. **Select Password Type**: Auto-generated (1) or custom password (2)
5. **Enter Quantity**: Specify how many accounts you want to create
6. **Wait for Results**: The tool will generate accounts and display them in the console
7. **Check Output**: All generated accounts are saved to `username.txt` in format: `Name | Email | Password | User ID`

## Name Lists
### Filipino Names
- **Male**: Juan, Jose, Miguel, Gabriel, Rafael, Antonio, Carlos, Luis, Marco, Paolo, Angelo, Joshua, and more
- **Female**: Maria, Ana, Sofia, Isabella, Gabriela, Valentina, Camila, Angelica, Nicole, Michelle, and more
- **Last Names**: Reyes, Santos, Cruz, Bautista, Garcia, Flores, Gonzales, Martinez, Ramos, and more

### RPW (Role-Play World) Names
- **Male**: Zephyr, Shadow, Phantom, Blaze, Storm, Frost, Raven, Ace, Knight, Wolf, Dragon, Phoenix, and more
- **Female**: Luna, Aurora, Mystic, Crystal, Sapphire, Scarlet, Violet, Rose, Athena, Venus, Nova, Stella, and more
- **Last Names**: Shadow, Dark, Light, Star, Moon, Sun, Sky, Night, Dawn, Storm, Frost, Fire

## Technical Details
- Uses fake_email library for temporary email generation
- Uses Facebook's mobile registration endpoint (www.facebook.com/reg/submit/)
- Dynamically extracts session tokens (fb_dtsg, jazoest, lsd, m_ts) from registration form
- Generates random user data based on selected name type
- Birthday range: January 1, 1990 to December 31, 2003
- Gender properly mapped to Facebook API requirements (male="2", female="1")
- No email confirmation or OTP verification required
- Uses random user agents to avoid detection

## Important Notes
- This tool creates accounts without email verification
- Account creation success depends on Facebook's API availability and rate limits
- The tool does NOT require proxies (unlike the old version)
- Created accounts are saved to username.txt with all login details
- Accounts may require additional verification from Facebook after creation

## Recent Changes
- **2025-10-31**: Initial setup in Replit environment
  - Installed Python 3.11
  - Created requirements.txt with proper dependencies
  - Set up workflow for CLI execution
  - Added .gitignore for Python project
  - Created project documentation

- **2025-10-31**: Major customization update
  - Added Filipino names support with authentic Filipino first and last names
  - Added RPW (role-play world) names for creative accounts
  - Implemented interactive menu for name type selection
  - Implemented interactive menu for gender selection
  - Changed birthday generation to 1999-2003 range
  - Simplified output to show only name, email, and password
  - Fixed gender mapping to properly work with Facebook API ('male'/'female')
  - Improved proxy filtering to ignore comment lines
  - Added timeouts to prevent hanging requests
  - Updated username.txt format for cleaner output

- **2025-10-31**: Complete rewrite with advanced features
  - Extracted auto-create method from advanced script
  - Installed beautifulsoup4, fake-useragent, fake_email dependencies
  - Implemented dynamic token extraction for session security
  - Removed proxy requirement (no longer needed)
  - Added custom password option
  - Changed birthday range to 1990-2003 (from 1999-2003)
  - Removed email confirmation/OTP functionality completely
  - Fixed hard-coded tokens to use dynamic form extraction
  - Improved error handling and user feedback
  - Updated output format to include User ID
